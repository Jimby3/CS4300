This homework assignment is to get us used to using python for CS4300
